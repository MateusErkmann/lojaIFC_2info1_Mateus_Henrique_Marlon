<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 16/11/2017
 * Time: 10:56
 */

require_once "Conexao.php";
require_once "Produto.php";

class CrudProdutos
{

    private $conexao;
    private $produto;

    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function salvar(Produto $produto)
    {
        $sql = "INSERT INTO tb_produtos (nome, preco, categoria, quantidade_estoque) VALUES ('$produto->nome', $produto->preco, '$produto->categoria', $produto->estoque)";

        $this->conexao->exec($sql);
    }

    public function excluir($codigo){
        $sql = "DELETE FROM tb_produtos WHERE codigo=$codigo";

        $this->conexao->exec($sql);


    }

    public function editar($codigo){
        $nome = $_POST['titulo'];
        $tipo = $_POST['categoria'];
        $quantidade = $_POST['quantidade'];
        $preco = $_POST['preco'];
        $sql = "UPDATE tb_produtos SET nome='$nome', categoria='$tipo', quantidade_estoque='$quantidade', preco='$preco' WHERE codigo='$codigo'";

        $this->conexao->query($sql);

        header("location: ../views/admin/produtos.php");
    }

    public function comprar($codigo, $quant){
        $quantidade = $quant - 1;
        $sql = "UPDATE tb_produtos SET quantidade_estoque=$quantidade WHERE codigo=$codigo";

        $this->conexao->query($sql);

        header("location: ../../index.php");

    }

    public function getProduto(int $codigo)
    {
        $consulta = $this->conexao->query("SELECT * FROM tb_produtos WHERE codigo = $codigo");
        $produto = $consulta->fetch(PDO::FETCH_ASSOC);

        return new Produto($produto['nome'], $produto['preco'], $produto['categoria'], $produto['quantidade_estoque'], $produto['codigo']);

    }

    public function getProdutos()
    {
        $consulta = $this->conexao->query("SELECT * FROM tb_produtos");
        $arrayProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

        //Fabrica de Produtos
        $listaProdutos = [];
        foreach ($arrayProdutos as $produto){
            $listaProdutos[] = new Produto($produto['nome'], $produto['preco'], $produto['categoria'], $produto['quantidade_estoque'], $produto['codigo']);
        }
        return $listaProdutos;
    }


}