﻿<!-- ## !!ADICIONE O CABECALHO E O RODAPE PARA A PAGINA -->
<?= require_once __DIR__."/cabecalho.php";
    $codigo = $_GET['codigo'];
?>


<h2>Editar Produtos</h2>
<form action="../../controllers/controladorProduto.php?acao=editar&codigo=<?=$codigo; ?>" method="post">
    <div class="form-group">
        <label for="produto">Produto:</label>
        <input name="titulo" type="text" class="form-control" id="produto" aria-describedby="nome produto" value="<?=$_GET['nome'];?>">
    </div>

    <div class="form-group">
        <label for="preco">Preco</label>
        <input name="preco" type="number" step="0.01" class="form-control" id="preco" value="<?=$_GET['preco'];?>">
    </div>

    <div class="form-group">
        <label for="quantidade">Quantidade</label>
        <input name="quantidade" type="number" class="form-control" id="quantidade" value="<?=$_GET['estoque'];?>">
    </div>

    <div class="form-group">
        <label for="Categoria">Categoria</label>
        <select name="categoria" class="form-control" id="Categoria">
            <option>Fruta</option>
            <option>Legume</option>
            <option>Hortaliça</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Salvar</button>

</form>